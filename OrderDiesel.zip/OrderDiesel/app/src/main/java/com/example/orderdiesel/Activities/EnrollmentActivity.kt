package com.example.orderdiesel.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.orderdiesel.R
import kotlinx.android.synthetic.main.activity_enrollment.*

class EnrollmentActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enrollment)

    }
}
